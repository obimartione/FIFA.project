﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Fifa_project
{
    public class Player <T> : IComparable<Player<string>>
    {
        public int Pac { get; set; }
        public int Dri { get; set; }
        public int Sho { get; set; }
        public int Def { get; set; }
        public int Pas { get; set; }
        public int Phy { get; set; }
        public List<T> Teams { get; set; }

        public Player(int pac, int dri, int sho, int def, int pas, int phy)
        {
            this.Pac = pac;
            this.Dri = dri;
            this.Sho = sho;
            this.Def = def;
            this.Pas = pas;
            this.Phy = phy;
            Teams = new List<T>();
        }
        
        public void editPac(int newPac)
        {
            Pac = newPac;
        }
        public void editDri(int newDri)
        {
            Dri = newDri;
        }
        public void editSho(int newSho)
        {
            Sho = newSho;
        }
        public void editDef(int newDef)
        {
            Def = newDef;
        }
        public void editPas(int newPas)
        {
            Pas = newPas;
        }
        //Edit physics
        public void editPhy(int newPhy)
        {
            Phy = newPhy;
        }
        //Add team
        public void AddTeam(T team)
        {
            Teams.Add(team);
        }

        //Comparer
        public int CompareTo([AllowNull] Player<string> other)
        {
            int playerXPropertiesCount = 0;
            int playerYPropertiesCout = 0;

            //Pac
            if (Pac > other.Pac)
            {
                playerXPropertiesCount++;
            }
            else if (other.Pac > Pac)
            {
                playerYPropertiesCout++;
            }

            //Shoting
            if (Sho > other.Sho)
            {
                playerXPropertiesCount++;
            }
            else if (other.Sho > Sho)
            {
                playerYPropertiesCout++;
            }

            //Drible
            if (Dri > other.Dri)
            {
                playerXPropertiesCount++;
            }
            else if (other.Dri > Dri)
            {
                playerYPropertiesCout++;
            }

            //Deffence
            if (Def > other.Def)
            {
                playerXPropertiesCount++;
            }
            else if (other.Def > Def)
            {
                playerYPropertiesCout++;
            }

            //Passing
            if (Pas > other.Pas)
            {
                playerXPropertiesCount++;
            }
            else if (other.Pas > Pas)
            {
                playerYPropertiesCout++;
            }

            //Physics
            if (Phy > other.Phy)
            {
                playerXPropertiesCount++;
            }
            else if (other.Phy > Phy)
            {
                playerYPropertiesCout++;
            }

            if (playerXPropertiesCount > playerYPropertiesCout)
            {
                return 1;
            }
            else if (playerYPropertiesCout > playerXPropertiesCount)
            {
                return -1;
            }
            else
            {
                return 0;
            }
        }

        //Iterator 
        public IEnumerable<T> GetPlayerTeams()
        {
            foreach (var team in Teams)
            {
                yield return team;
            }
        }
    }
}
