﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Fifa_project
{
    class Program
    {
        static void Main(string[] args)
        {
            Player<string> Marto = new Player<string>(88, 87, 94, 34, 88, 86);
            Player<string> Alexander = new Player<string>(92, 80, 85, 45, 83, 83);

            Console.WriteLine("Player specs: ");

            string specs = string.Empty;
            // Main menu
            while ((specs = Console.ReadLine()) != "Bye")
            {
                //Display the pac of the player.
                if (specs == "Pac")
                {
                    int choise = GetPlayer();

                    if (choise == 1)
                    {
                        Console.WriteLine(Marto.Pac);
                        continue;
                    }
                    if (choise == 2)
                    {
                        Console.WriteLine(Alexander.Pac);
                        continue;
                    }


                }
                // Alters the Pac of the player
                else if (specs == "Edit Pac")
                {
                    int choise = GetPlayer();
                    Console.WriteLine("New Pac: ");
                    int num = int.Parse(Console.ReadLine());
                    if (choise == 1)
                    {
                        Marto.editPac(num);
                        Console.WriteLine("The pac is now: " + num);
                        continue;
                    }
                    if (choise == 2)
                    {
                        Alexander.editPac(num);
                        Console.WriteLine("The pac is now: " + num);
                        continue;
                    }
                }

                if (specs == "Dri")
                {
                    int choise = GetPlayer();

                    if (choise == 1)
                    {
                        Console.WriteLine(Marto.Dri);
                    }

                    if (choise == 2)
                    {
                        Console.WriteLine(Alexander.Dri);
                    }

                    continue;

                }
                //Display the Dri of the player
                if (specs == "Dri")
                {
                    Console.WriteLine(Marto.Dri);
                    continue;

                }
                //Alter the Dri of the player
                else if (specs == "Edit Dri")
                {
                    Console.WriteLine("New Dri: ");
                    int num = int.Parse(Console.ReadLine());
                    Marto.editDri(num);
                    Console.WriteLine("The dri is now: " + Marto.Dri);
                    continue;
                }

                if (specs == "Sho")
                {
                    int choise = GetPlayer();

                    if (choise == 1)
                    {
                        Console.WriteLine(Marto.Sho);
                    }

                    if (choise == 2)
                    {
                        Console.WriteLine(Alexander.Sho);
                    }

                    continue;

                }
                //Display the shooting of the player;
                if (specs == "Sho")
                {
                    Console.WriteLine(Marto.Sho);
                    continue;

                }
                //Alter the shooting of the player;
                else if (specs == "Edit Sho")
                {
                    Console.WriteLine("New Sho: ");
                    int num = int.Parse(Console.ReadLine());
                    Marto.editSho(num);
                    Console.WriteLine("The sho is now: " + Marto.Sho);
                    continue;
                }

                if (specs == "Def")
                {
                    int choise = GetPlayer();

                    if (choise == 1)
                    {
                        Console.WriteLine(Marto.Def);
                    }

                    if (choise == 2)
                    {
                        Console.WriteLine(Alexander.Def);
                    }

                    continue;

                }
                //Display the defence of the player
                if (specs == "Def")
                {
                    Console.WriteLine(Marto.Def);
                    continue;

                }
                //Alter the deffence of the player
                else if (specs == "Edit Def")
                {
                    Console.WriteLine("New Def: ");
                    int num = int.Parse(Console.ReadLine());
                    Marto.editDef(num);
                    Console.WriteLine("The def is now: " + Marto.Def);
                    continue;
                }

                if (specs == "Pas")
                {
                    int choise = GetPlayer();

                    if (choise == 1)
                    {
                        Console.WriteLine(Marto.Pas);
                    }

                    if (choise == 2)
                    {
                        Console.WriteLine(Alexander.Pas);
                    }

                    continue;

                }
                //Display the passing skill of the player
                if (specs == "Pas")
                {
                    Console.WriteLine(Marto.Pas);
                    continue;

                }
                //Alter the passing skill of the player
                else if (specs == "Edit Pas")
                {
                    Console.WriteLine("New Pas: ");
                    int num = int.Parse(Console.ReadLine());
                    Marto.editPas(num);
                    Console.WriteLine("The pas is now: " + Marto.Pas);
                    continue;
                }

                //Display the physics of the player
                if (specs == "Phy")
                {
                    int choise = GetPlayer();

                    if (choise == 1)
                    {
                        Console.WriteLine(Marto.Phy);
                    }

                    if (choise == 2)
                    {
                        Console.WriteLine(Alexander.Phy);
                    }

                    continue;

                }
                //Alter the physics of the player
                else if (specs == "Edit Phy")
                {
                    Console.WriteLine("New Phy: ");
                    int num = int.Parse(Console.ReadLine());
                    Marto.editPhy(num);
                    Console.WriteLine("The phy is now: " + Marto.Phy);
                    continue;
                }
                //Add new team to plyer teams
                else if (specs == "Add team")
                {
                    Console.WriteLine("Enter team name");
                    string team = Console.ReadLine();
                    Marto.AddTeam(team);
                    Console.WriteLine("team was added successfully");
                    continue;
                }
                //Display all teams of the player with iterator technique 1
                else if (specs == "Teams")
                {
                    Console.WriteLine("Teams: ");
                    string resultMessage = string.Empty;
                    //Iterate throw all records
                    foreach (var team in Marto.Teams)
                    {
                        resultMessage += $"{team}, ";
                    }

                    int indexOfComma = resultMessage.LastIndexOf(',');

                    if (indexOfComma < 0)
                    {
                        continue;
                    }

                    resultMessage = resultMessage.Substring(0, indexOfComma);
                    Console.WriteLine(resultMessage);
                    continue;

                }
                // Dislay all teams of player with iterator technique 2
                else if (specs.ToLower() == "teams2")
                {
                    IEnumerable<string> teams = Marto.GetPlayerTeams();

                    if (teams.Count() < 1)
                    {
                        Console.WriteLine("Player doesnt have any teams!");
                        continue;
                    }

                    Console.WriteLine("Marto has player in: " + string.Join(',', teams));
                    continue;
                }
                else if (specs.ToLower().Trim() == "compare")
                {
                    if (Marto.CompareTo(Alexander) == 1)
                    {
                        Console.WriteLine("Player Marto has better stats than Player Alexander.");
                    }
                    else if (Marto.CompareTo(Alexander) < 0)
                    {
                        Console.WriteLine("Player Alexander has better stats than Player Marto.");
                    }
                    else
                    {
                        Console.WriteLine("Both players have equal stats!");
                    }
                    continue;
                }

                Console.WriteLine("Invalid Command!");

            }

        }

        static int GetPlayer()
        {
            Console.WriteLine("Choose player: ");
            Console.WriteLine("1. Matro");
            Console.WriteLine("2. Alexander");

            int choise = int.Parse(Console.ReadLine());
            return choise;
        }
    }
}
